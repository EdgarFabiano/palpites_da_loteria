# palpites_da_loteria

A Flutter app.

The "Palpites da loteria" app lets you manage games for lottery contests quickly and easily.
With its beautiful and simple-to-use interface, you can raffle dozens of lottery contests as many times as you like.

[Download](https://play.google.com/store/apps/details?id=com.efs.palpites_da_loteria)
